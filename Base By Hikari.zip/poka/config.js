/*
Base Whatsapp Bot
By Hikari Archive

Youtube: @HikariArchive
*/

//~~~~~Setting Global~~~~~//

global.owner = ["6281334148237"] // Nomor Pemilik
global.bot = "6281334148237" // Nomor Bot
global.namabot = "pokasyz" // Nama Bot
global.namaown = "Poka1337" // Nama owner

//~~~~~Status Diperbarui~~~~~//
let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})