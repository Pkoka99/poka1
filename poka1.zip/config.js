/*
Base Script Bot Whatsapp By DapszzOfficial
Support Pairing Code
Script No Enc
Youtube: DapszzSamp
*/

//Settings
global.owner = ["6281334148237"] // Nomor Pemilik
global.bot = "6281334148237" // Nomor Bot
global.namabot = "pokasyz" // Nama Bot
global.namaown = "Poka1337" // Nama owner

global.domain = 'poka.my.id'//ganti dengan domain panel kalian
global.apikey = '' // Isi Apikey Plta Lu
global.capikey = '' // Isi Apikey Pltc Lu
global.eggbotjs = '16' // id eggs js kalian
global.location = '1' //Id Location
//Log Di Perbarui Suqi
let fs = require('fs')
let file = require.resolve(__filename)
fs.watchFile(file, () => {
fs.unwatchFile(file)
console.log(`Update ${__filename}`)
delete require.cache[file]
require(file)
})